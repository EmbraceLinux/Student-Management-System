#ifndef STUDENT_H
#define STUDENT_H

#include <stdio.h>

typedef struct Student
{
	char name[20];
	char sex;
	int id;
}Student;

#define STU_MAX 10000

#define STU_SIZE sizeof(Student)

static void show_stu(const void* ptr)
{
	if(NULL == ptr) return;
	const Student* stu = ptr;
	printf("姓名：%s 性别：%c 学号%d\n",
		stu->name,stu->sex,stu->id);
}

#endif//STUDENT_H
