#ifndef SIMS_H
#define SIMS_H

// 初始化链表、加载数据
void init_sims(void);
// 进入学生信息管理系统
void start_sims(void);
// 保存数据、销毁链表
void exit_sims(void);

#endif//SIMS_H
