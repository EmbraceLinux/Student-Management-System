#ifndef USER_H
#define USER_H

#include <list.h>
#include <tools.h>

typedef struct User
{
	char acc[20];
	char pwd[9];
	char lock;
}User;

#define USER_SIZE sizeof(User)

// 存储用户账户信息的链表
extern List* user_list;

// 存储学生信息的链表
extern List* stu_list;

// 登录
State user_login(const char* acc,const char* pwd);

#endif//USER_H
