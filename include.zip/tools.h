#ifndef TOOLS_H
#define TOOLS_H

#include <list.h>

#define pf printf
#define sf scanf

typedef enum {
	Error=-1,
	NameError,
	PassError,
	IsLock,
	LoginOk
}State;

void quick_sort(const void* arr[],size_t len,compar cmp);

char get_cmd(char start,char end);

void clear_stdin(void);

int binary_find(const void* arr[],size_t len,const void* key,compar cmp);

#endif//TOOLS_H
