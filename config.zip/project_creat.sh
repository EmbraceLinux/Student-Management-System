# 程序入口
touch main.c
# 学生信息管理系统主控模块
touch sims.c sims.h
# 超级管理员模块
touch admin.c admin.h
# 用户模块
touch user.c user.h
# 工具模块
touch tools.c tools.h
# 链表模块
touch list.c list.h
# 文件操作模块
touch dao.c dao.h
# 编译脚本
ls > Makefile

