	List* list = creat_list();
	for(int i=0; i<5; i++)
	{
		Student* stu = malloc(STU_SIZE);
		strcpy(stu->name,"haha");
		stu->sex = 'a'+rand()%26;
		stu->id = 10010+rand()%1000;
		add_tail_list(list,stu);
	}
	save(list,STU_PATH,STU_SIZE);
	
	
	user_list = creat_list();
	for(int i=0; i<5; i++)
	{
		User* user = malloc(USER_SIZE);
		sprintf(user->acc,"%d",10010+i);
		sprintf(user->pwd,"1234");
		user->lock = 0;
		pf("%s",user->acc);
		add_tail_list(user_list,user);
	}
	save(user_list,USER_PATH,USER_SIZE);
